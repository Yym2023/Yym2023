<template>
  <div class="hello">
    <Button type="success">Success</Button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld'
}
</script>
