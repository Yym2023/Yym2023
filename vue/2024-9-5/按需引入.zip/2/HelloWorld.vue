<template>
  <div class="hello">
    <Button type="success">Success</Button>
  </div>
</template>

<script>
import { Button, Table } from 'view-design';
export default {
  name: 'HelloWorld',
  components: {
    Button,
    Table
  }
}
</script>
